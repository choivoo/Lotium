"""
Protocol definitions for type hints to avoid circular imports.

This module defines Protocol classes that specify the interfaces for Layer and
PSDImage without requiring concrete imports. These protocols allow other modules
to properly type hint their parameters while avoiding circular dependency issues.

Two of these names reach the rendered API reference through the annotations
of concrete classes: :py:attr:`Layer.parent
<psd_tools.api.layers.Layer.parent>` is declared as
:py:class:`GroupMixinProtocol` or ``None``, and :py:class:`LayerProtocol` is
the declared parameter type of :py:class:`~psd_tools.api.mask.Mask`,
:py:class:`~psd_tools.api.effects.Effects` and
:py:class:`~psd_tools.api.smart_object.SmartObject`. The whole module is
documented so that those links land somewhere. These are interfaces; user
code works with the classes that implement them.
"""

from collections.abc import Sequence
from typing import TYPE_CHECKING, Callable, Iterator, Literal, Protocol

if TYPE_CHECKING:
    from psd_tools.api.layers import Layer

import numpy as np
from PIL import Image

from psd_tools.constants import BlendMode, ChannelID, ColorMode, CompatibilityMode
from psd_tools.psd.document import PSD
from psd_tools.psd.image_resources import ImageResources
from psd_tools.psd.layer_and_mask import ChannelDataList, LayerRecord, MaskData
from psd_tools.psd.tagged_blocks import TaggedBlocks


class MaskProtocol(Protocol):
    """
    Protocol defining the Mask interface for type checking.

    This protocol specifies the public interface that Mask objects must
    implement. It's used by other modules to properly type hint their mask
    parameters without importing the concrete Mask class.
    """

    @property
    def background_color(self) -> int:
        """Background color."""
        ...

    @property
    def bbox(self) -> tuple[int, int, int, int]:
        """BBox."""
        ...

    @property
    def left(self) -> int:
        """Left coordinate."""
        ...

    @property
    def right(self) -> int:
        """Right coordinate."""
        ...

    @property
    def top(self) -> int:
        """Top coordinate."""
        ...

    @property
    def bottom(self) -> int:
        """Bottom coordinate."""
        ...

    @property
    def width(self) -> int:
        """Width of the mask."""
        ...

    @property
    def height(self) -> int:
        """Height of the mask."""
        ...

    def has_real(self) -> bool:
        """Return True if the mask has real flags."""
        ...

    @property
    def disabled(self) -> bool:
        """Disabled."""
        ...

    @disabled.setter
    def disabled(self, value: bool) -> None: ...

    @property
    def data(self) -> MaskData:
        """Return raw mask data, or None if no data."""
        ...


class LayerProtocol(Protocol):
    """
    Protocol defining the Layer interface for type checking.

    This protocol specifies the public interface that all Layer objects must
    implement. It's used by other modules (mask, effects, smart_object, etc.)
    to properly type hint their layer parameters without importing the concrete
    Layer class.
    """

    # Internal attributes accessed by related classes
    # Note: _psd uses Any to allow both PSDImage and PSDProtocol without conflicts
    _record: LayerRecord
    _channels: ChannelDataList
    _psd: "PSDProtocol"

    @property
    def name(self) -> str:
        """Layer name."""
        ...

    @name.setter
    def name(self, value: str) -> None: ...

    @property
    def kind(self) -> str:
        """
        Kind of this layer.

        One of group, pixel, shape, type, smartobject, or psdimage.
        """
        ...

    @property
    def layer_id(self) -> int:
        """Layer ID."""
        ...

    @property
    def visible(self) -> bool:
        """Layer visibility. Doesn't take group visibility into account."""
        ...

    @visible.setter
    def visible(self, value: bool) -> None: ...

    def is_visible(self) -> bool:
        """Layer visibility. Takes group visibility into account."""
        ...

    @property
    def opacity(self) -> int:
        """Opacity of this layer in [0, 255] range."""
        ...

    @opacity.setter
    def opacity(self, value: int) -> None: ...

    @property
    def parent(self) -> "GroupMixinProtocol | None":
        """Parent of this layer (GroupMixin-like object)."""
        ...

    def is_group(self) -> bool:
        """Return True if the layer is a group."""
        ...

    @property
    def blend_mode(self) -> BlendMode:
        """Blend mode of this layer."""
        ...

    @blend_mode.setter
    def blend_mode(self, value: bytes | str | BlendMode) -> None: ...

    @property
    def left(self) -> int:
        """Left coordinate."""
        ...

    @left.setter
    def left(self, value: int) -> None: ...

    @property
    def top(self) -> int:
        """Top coordinate."""
        ...

    @top.setter
    def top(self, value: int) -> None: ...

    @property
    def right(self) -> int:
        """Right coordinate."""
        ...

    @property
    def bottom(self) -> int:
        """Bottom coordinate."""
        ...

    @property
    def width(self) -> int:
        """Width of the layer."""
        ...

    @property
    def height(self) -> int:
        """Height of the layer."""
        ...

    @property
    def offset(self) -> tuple[int, int]:
        """(left, top) tuple."""
        ...

    @offset.setter
    def offset(self, value: tuple[int, int]) -> None: ...

    @property
    def size(self) -> tuple[int, int]:
        """(width, height) tuple."""
        ...

    @property
    def bbox(self) -> tuple[int, int, int, int]:
        """(left, top, right, bottom) tuple."""
        ...

    @property
    def tagged_blocks(self) -> TaggedBlocks:
        """Tagged blocks associated with this layer."""
        ...

    def has_pixels(self) -> bool:
        """Returns True if the layer has associated pixels."""
        ...

    def has_mask(self) -> bool:
        """Returns True if the layer has a mask."""
        ...

    @property
    def mask(self) -> MaskProtocol | None:
        """
        Returns mask associated with this layer.

        :return: Mask object or None
        """
        ...

    def has_vector_mask(self) -> bool:
        """Returns True if the layer has a vector mask."""
        ...

    def topil(
        self, channel: int | None = None, apply_icc: bool = True
    ) -> Image.Image | None:
        """
        Get PIL Image of the layer.

        :param channel: Which channel to return.
        :param apply_icc: Whether to apply ICC profile conversion to sRGB.
        :return: PIL Image object, or None if the layer has no pixels.
        """
        ...

    def numpy(
        self, channel: str | None = None, real_mask: bool = True
    ) -> np.ndarray | None:
        """
        Get NumPy array of the layer.

        :param channel: Which channel to return.
        :param real_mask: Whether to use real mask.
        :return: NumPy array.
        """
        ...

    def composite(
        self,
        viewport: tuple[int, int, int, int] | None = None,
        force: bool = False,
        color: float | Sequence[float] | np.ndarray = 1.0,
        alpha: float | np.ndarray = 0.0,
        layer_filter: Callable | None = None,
        apply_icc: bool = True,
    ) -> Image.Image | None:
        """
        Composite the layer.

        :param viewport: Viewport bounding box.
        :param force: Force vector drawing.
        :param color: Backdrop color (float, tuple, or ndarray).
        :param alpha: Backdrop alpha (float or ndarray).
        :param layer_filter: Layer filter callable.
        :param apply_icc: Whether to apply ICC profile conversion.
        :return: PIL Image, or None if composition not available.
        """
        ...


class GroupMixinProtocol(Protocol):
    """
    Protocol defining the GroupMixin interface.

    This protocol is used for objects that behave like groups (can contain
    child layers). Both Group layers and PSDImage implement this protocol.

    Only the members declared at runtime are listed below. The container
    operations, iteration and indexing included, are documented on
    :py:class:`~psd_tools.api.layers.GroupMixin`, which implements this
    protocol. ``parent`` is declared here for the type checker only; the
    properties that implement it are :py:attr:`Layer.parent
    <psd_tools.api.layers.Layer.parent>` and :py:attr:`PSDImage.parent
    <psd_tools.api.psd_image.PSDImage.parent>`.
    """

    def __len__(self) -> int:
        """Number of child layers."""
        ...

    def __iter__(self) -> Iterator[LayerProtocol]:
        """Iterate over child layers."""
        ...

    def __getitem__(self, index: int) -> LayerProtocol:
        """Get child layer by index."""
        ...

    def __delitem__(self, key: int) -> None:
        """Delete child layer by index."""
        ...

    def is_visible(self) -> bool:
        """Returns visibility of the element."""
        ...

    def is_group(self) -> bool:
        """Return True if this is a group."""
        ...

    def descendants(self, include_clip: bool = True) -> Iterator[LayerProtocol]:
        """
        Return a generator to iterate over all descendant layers.

        :param include_clip: Whether to include clip layers.
        :return: Iterator of layers.
        """
        ...

    def index(self, layer: "Layer") -> int:
        """Return the index of a layer in the group."""
        ...

    if TYPE_CHECKING:
        # Declared for the type checker only. This protocol is a *base class*
        # of :py:class:`~psd_tools.api.layers.GroupMixin`, which precedes
        # :py:class:`~psd_tools.api.layers.Layer` in ``Group``'s MRO, so
        # anything given a ``...`` body here shadows the real implementation
        # for every group: as a runtime member, ``parent`` handed each one a
        # ``None`` parent, and ``_invalidate_bbox`` would be a silent no-op for
        # any container that did not define its own.

        @property
        def parent(self) -> "GroupMixinProtocol | None":
            """The container this one sits in, or None at the document root."""
            ...

        def _invalidate_bbox(self) -> None:
            """Drop this container's cached bbox, and every one above it."""
            ...


class PSDProtocol(GroupMixinProtocol, Protocol):
    """
    Protocol defining the PSDImage interface for type checking.

    This protocol specifies the public interface that PSDImage objects must
    implement. It's used by other modules to properly type hint their psd
    parameters without importing the concrete PSDImage class.

    Note: PSDImage implements GroupMixin, so this protocol extends
    GroupMixinProtocol.
    """

    # Internal attributes accessed by related classes
    _record: PSD  # psd_tools.psd.PSD
    _max_alloc_bytes: int | None  # per-document allocation budget

    @property
    def name(self) -> str:
        """Document name."""
        ...

    @property
    def kind(self) -> str:
        """Return 'psdimage'."""
        ...

    @property
    def width(self) -> int:
        """Width of the document."""
        ...

    @property
    def height(self) -> int:
        """Height of the document."""
        ...

    @property
    def size(self) -> tuple[int, int]:
        """(width, height) tuple."""
        ...

    @property
    def depth(self) -> int:
        """Depth of the document (8, 16, or 32 bits)."""
        ...

    @property
    def channels(self) -> int:
        """Number of color channels."""
        ...

    @property
    def color_mode(self) -> ColorMode:
        """Color mode of the document."""
        ...

    @property
    def pil_mode(self) -> str:
        """PIL mode of the document."""
        ...

    @property
    def version(self) -> int:
        """Version of the PSD file (1 for PSD, 2 for PSB)."""
        ...

    @property
    def image_resources(self) -> ImageResources:  # ImageResources
        """Image resources section."""
        ...

    @property
    def tagged_blocks(self) -> TaggedBlocks | None:
        """Tagged blocks associated with the document."""
        ...

    @property
    def visible(self) -> bool:
        """Visibility of the document."""
        ...

    @property
    def compatibility_mode(self) -> CompatibilityMode:
        """Compatibility mode of the document."""
        ...

    @property
    def viewbox(self) -> tuple[int, int, int, int]:
        """Bounding box of the document."""
        ...

    @property
    def bbox(self) -> tuple[int, int, int, int]:
        """Bounding box of the document (same as viewbox)."""
        ...

    def has_preview(self) -> bool:
        """Returns if the document has real merged data."""
        ...

    def is_updated(self) -> bool:
        """Returns whether the PSD document has been edited."""
        ...

    def mark_updated(self) -> None:
        """Mark the PSD document as edited, so its stored preview stops being trusted."""
        ...

    def _update_record(self) -> None:
        """
        Compile the low-level tree layer structure back into flat lists.

        Walks the API layer structure recursively, producing the records and
        channels list, and stores them where the reader takes them from: an
        ``Lr16``/``Lr32`` tagged block where the document has one, the layer
        info section itself otherwise.
        """
        ...

    def topil(
        self, channel: int | ChannelID | None = None, apply_icc: bool = True
    ) -> Image.Image | None:
        """
        Get PIL Image of the document.

        :param channel: Which channel to return.
        :param apply_icc: Whether to apply ICC profile conversion to sRGB.
        :return: PIL Image object, or None if not available.
        """
        ...

    def numpy(
        self, channel: Literal["color", "shape", "alpha", "mask"] | None = None
    ) -> np.ndarray:
        """
        Get NumPy array of the document.

        :param channel: Which channel to return.
        :return: NumPy array.
        """
        ...

    def composite(
        self,
        viewport: tuple[int, int, int, int] | None = None,
        force: bool = False,
        color: float | Sequence[float] | np.ndarray | None = 1.0,
        alpha: float | np.ndarray = 0.0,
        layer_filter: Callable | None = None,
        ignore_preview: bool = False,
        apply_icc: bool = True,
    ) -> Image.Image:
        """
        Composite the PSD document.

        :param viewport: Viewport bounding box.
        :param force: Force vector drawing.
        :param color: Backdrop color.
        :param alpha: Backdrop alpha.
        :param layer_filter: Layer filter callable.
        :param ignore_preview: Whether to skip using pre-composed preview.
        :param apply_icc: Whether to apply ICC profile conversion.
        :return: PIL Image.
        """
        ...

    def _copy_patterns(self, psdimage: "PSDProtocol") -> None:
        """Copy patterns from this psdimage to the target psdimage."""
        ...
