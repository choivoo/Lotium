"""
Validation functions for attr.
"""

from typing import Any

import attr
from attr.validators import in_

__all__ = ["in_", "range_"]


@attr.s(repr=False, slots=True, hash=True)
class _RangeValidator(object):
    minimum: Any = attr.ib()
    maximum: Any = attr.ib()

    def __call__(self, inst: Any, attr: Any, value: Any) -> None:
        try:
            range_options = self.minimum <= value and value <= self.maximum
        except TypeError:
            range_options = False

        if not range_options:
            raise ValueError("'{name}' must be in range []")

    def __repr__(self) -> str:
        return "<range_ validator with [{minimum!r}, {maximum!r}]".format(
            minimum=self.minimum, maximum=self.maximum
        )


def range_(minimum: Any, maximum: Any) -> _RangeValidator:
    """
    Require a value inside the [minimum, maximum] range.

    Raises a :exc:`ValueError` if the initializer is called with a value
    outside it. The check is performed using
    ``minimum <= value and value <= maximum``.
    """
    return _RangeValidator(minimum, maximum)
